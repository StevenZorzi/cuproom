
    <!--JAVASCRIPT-->
    <!--=================================================-->

    <!--jQuery [ REQUIRED ]-->
    {!! Html::script('js/jquery-2.2.1.min.js') !!}


    <!--BootstrapJS [ RECOMMENDED ]-->
    {!! Html::script('js/bootstrap.min.js') !!}


    <!--Fast Click [ OPTIONAL ]-->
    {!! Html::script('plugins/fast-click/fastclick.min.js') !!}

    
    <!--Nifty Admin [ RECOMMENDED ]-->
    {!! Html::script('js/nifty.min.js') !!}


    <!--Background Image [ DEMONSTRATION ]-->
    {!! Html::script('js/demo/bg-images.js') !!}