@extends('templates.template-error', ['code' => '410'])
