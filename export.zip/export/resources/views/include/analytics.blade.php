@if($_SERVER['SERVER_NAME']!="round.myqnapcloud.com")
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-117517968-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-117517968-1', { 'anonymize_ip': true });
</script>
@endif
