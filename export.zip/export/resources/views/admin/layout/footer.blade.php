
<!-- FOOTER -->
<!--===================================================-->
<footer id="footer">


    <!-- Visible when footer positions are static -->
    <!-- ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->
    <div class="hide-fixed pull-right pad-rgt"><a href="http://www.roundstudio.it/" title="ROUND studio - Agenzia web - Montebelluna - TREVISO" target="_blank">Created by ROUND Studio</a></div>


    <p class="pad-lft">&#0169; <?php echo date('Y') ?> <strong>{{config('app.name')}}</strong></p>



</footer>
<!--===================================================-->
<!-- END FOOTER -->


<!-- SCROLL TOP BUTTON -->
<!--===================================================-->
<button id="scroll-top" class="btn"><i class="fa fa-chevron-up"></i></button>
<!--===================================================-->
