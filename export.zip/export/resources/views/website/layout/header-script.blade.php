 
{!! Html::style('css/pages/website/foundation.min.css') !!} 
{!! Html::style('css/pages/website/screen.css') !!} 

<!-- fonts --> 
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet"> 
<link href="http://fonts.cdnfonts.com/css/bebas-neue?styles=17623,17625,17621,17620" rel="stylesheet">
                


{!! Html::style('plugins/animate-css/animate.css') !!} 

{!! Html::style('css/pages/website/custom.css?v=2.1') !!} 
{!! Html::style('css/pages/website/custom2022.css?v=2.1') !!} 
<!-- jquery -->
{!! Html::script('js/pages/website/vendor/jquery.js') !!} 

{!! Html::script('plugins/imagelinks/jquery.imagelinks.min.js') !!} 
{!! Html::style('plugins/imagelinks/imagelinks.min.css') !!} 
{!! Html::style('plugins/imagelinks/imagelinks.theme.dark.min.css') !!} 
